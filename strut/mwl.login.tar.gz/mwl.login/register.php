<?php
require_once 'util.inc';

function register($salt, $login, $name,  $password) {
	$con = connectDb();

	$stmt = $con->prepare("UPDATE user SET name=:name, alcunha=:alcunha, login=:login, password=:password WHERE sal=:salt;");

	$password = md5($_REQUEST['password'] . strrev($_REQUEST['login']));

	$bind = array(":name"=>$name, ":alcunha"=>$alcunha, ":login"=>$login, ":password"=>$password, ":salt"=>$salt);

	$stmt->execute($bind);
	$affRows = $stmt->rowCount();

	if ($affRows == 0) {
		$errCode = 401;
	} else { $errCode = 200; }
    return $errCode;
}

$salt = $_REQUEST['salt'];

if (!array_key_exists('salt', $_REQUEST)){
	$errCode = 400;
}

if(!(array_key_exists('login', $_REQUEST) && array_key_exists('password', $_REQUEST))) {
	$errCode = 400;
}

if (!isset($errCode)) {	
  register($salt, $_REQUEST['login'], $_REQUEST['name'], $_REQUEST['password']);

  $arResult = array("errcode"=> $errCode);

  if ($_REQUEST['show'] == 1)
    echo json_encode($arResult);	
}
?>
