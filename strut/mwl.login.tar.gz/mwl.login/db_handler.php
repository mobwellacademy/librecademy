<?php
$fileprop = pathinfo($_SERVER['SCRIPT_NAME']);
$pinfo = explode("/", $fileprop['dirname']);
$utilloc = $_SERVER['DOCUMENT_ROOT']."/".$pinfo[1].'/auth/util.inc';
include_once $utilloc;

function readTable($table, $where) {
	$con = connectDb();

	$sel = "SELECT * FROM $table ";
	if ($where != null) {
		$sel .= " WHERE ";
		$count = 0;
		foreach($where as $key=>$val) {
			$sel .= (($count == 0) ? "" : " AND ") . "$key=$val";
			$count++;
		}	
	}

//	die($sel);

	$stmt = $con->prepare($sel);
	$stmt->execute();
	$arRes = $stmt->fetchAll(PDO::FETCH_ASSOC);
	return $arRes;
}

function insertTable($table, $arvalues) {

	$con = connectDb();

	$sel = "INSERT INTO $table (";
	$secpart = "";
	$count = 0;
	foreach($arvalues as $key=>$val) {
		$sel .=(($count == 0) ? "" : ", ") . $key;
		$secpart .= (($count == 0) ? "" : ", ") . $val;
		$count++;
	}
	$sel .= ") VALUES ($secpart);";
//  die ($sel);
	$stmt = $con->prepare($sel);
	$stmt->execute();
}

function updateTable($table, $arvalues, $where) {
	$con = connectDb();

	$sel = "UPDATE $table SET ";
	$count = 0;
	foreach($arvalues as $key=>$val) {
		$sel .= (($count == 0) ? "" : ", ") ."$key=$val";
		$count++;
	}

	$sel .= " WHERE ";
	$count = 0;
	foreach($where as $key=>$val) {
		$sel .= (($count == 0) ? "" : " AND ") . "$key=$val";
		$count++;
	}	

	// die($sel);

	$stmt = $con->prepare($sel);
	$stmt->execute();
}


?>
