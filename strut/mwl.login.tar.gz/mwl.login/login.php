<?php

require_once 'util.inc';

$login = $_REQUEST['login'];

if (!array_key_exists('phs', $_REQUEST))
die('Must provide phase');

if (!array_key_exists('login', $_REQUEST))
die('Must provide login');

if (strcmp($_REQUEST['phs'], "2")== 0) {
	if (!array_key_exists('password', $_REQUEST)) {
		die('Must provide password');
	}
}

$con = connectDb();

$stmt = $con->prepare("SELECT * FROM user WHERE login=:login");
$stmt->execute(array(":login"=>$login));
$arResult =  $stmt->fetchAll(PDO::FETCH_ASSOC);
$sal = "null";

if (empty($arResult)){
	$arOut = array("sal"=>"false", "errcode"=>"404");
}
else {
	$sal = $arResult[0]['sal'];
	$arOut = array("errcode"=>"200", "sal"=>$sal);
 if (strcmp($_REQUEST['phs'], "2")==0) {
	 $passwd = $arResult[0]['password'];
	 $passRec = md5($_REQUEST['password'].strrev($login));
// echo "<br/>$passwd<br/>$passRec";
	 if (strcmp($passwd,$passRec)==0) {
		 // Last Login
		 $lastLogin = date("Y-m-d H:i:s", time());
		 $avtoken = md5($sal . $login . time());
		 $arbind = array(":llogin"=>$lastLogin, ":login"=>$login, ":activeToken"=>$avtoken);

		 $stmt = $con->prepare("UPDATE user SET lastLogin = :llogin, active_token=:activeToken WHERE login=:login");
		 $stmt->execute($arbind);
		 $affRows = $stmt->rowCount();


		 $arOut = array("activeToken"=>"$avtoken", "errcode"=>"200");
	 }	
	 else {
		 $arOut = array("activeToken"=>"null", "errcode"=>"401");
	 }	
 }
}

echo json_encode($arOut);

?>
