<?php

require_once 'util.inc';

if (!array_key_exists('token', $_REQUEST)) {
	$errCode = 400;
}
else {
	$con = connectDb();

	$stmt = $con->prepare("UPDATE user SET active_token='' WHERE active_token=:atoken");
	$stmt->execute(array(":atoken"=>$_REQUEST[token]));
	$affRows = $stmt->rowCount();

	if ($affRows == 1) {
		$errCode = 200;
	} else {
		$errCode = 204;
	}
}
echo json_encode(array("errcode"=>$errCode));

?>
