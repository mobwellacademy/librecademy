create table if not exists user( id_user int NOT NULL AUTO_INCREMENT, 
    name varchar(150), 
    alcunha varchar(100), 
    login varchar(50) UNIQUE, 
    password varchar(150), 
    createdate datetime, 
    lastlogin datetime, 
    active_token tinytext, 
    sal VARCHAR(200) UNIQUE, 
    description longtext, 
    PRIMARY KEY (id_user));

create trigger `creationdate` before insert on `user` for each ROW SET NEW.createdate = NOW(), NEW.sal=MD5(CURRENT_TIMESTAMP+ RAND()) ;

