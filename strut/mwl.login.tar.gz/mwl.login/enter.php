<?php
session_start();

require_once('auth/login.php');
require_once('auth/tools.php');

$artoken = login($_REQUEST['login'], $_REQUEST['password']);
$user = user_by_activetoken($artoken['activeToken']);

$_SESSION['user'] = $user[0];

header("Location: ". $_REQUEST['php_self']);
?>
